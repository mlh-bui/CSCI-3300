package oop.hospital.v1;

public enum Shift {
    DAY, NIGHT, ROTATED, DAY_WITH_BEEPER_CALLS, DAY_WITH_OCCASIONAL_NIGHTS

}