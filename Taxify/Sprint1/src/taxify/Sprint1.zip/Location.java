// V.1 Project: Taxify
// Implement ILocation
// Marissa Bui - CSCI 3300 - 2/3

package taxify;

public class Location {
    /** x-coordinate for map */
    private int x;

    /** y-coordinate for map */
    private int y;

    /** Basic constructor */
    public Location(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /* Accessors & Mutators */
    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public String toString() {
        return this.x + " " + this.y;
    }

} // class Location
