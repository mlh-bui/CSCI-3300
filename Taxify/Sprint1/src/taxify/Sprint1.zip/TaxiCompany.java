package taxify;

public class TaxiCompany {
    private String name;

    public TaxiCompany(String name) {
        this.name = name;
    }

    public int getTotalServices() {
        return 0;
    }

    public boolean requestService(int user) {
        return false;
    }

} // class TaxiCompany