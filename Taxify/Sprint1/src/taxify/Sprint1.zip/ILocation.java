package taxify;

public interface ILocation {
    public int getX();
    public int getY();
    public String toString();

} // interface ILocation