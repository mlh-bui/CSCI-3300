package taxify;

public interface ITaxiCompany1 {

    public String getName();
    public int getTotalServices();
    public boolean requestService(int user);

    // more methods will be declared in upcoming sprints

} // interface ITaxiCompany